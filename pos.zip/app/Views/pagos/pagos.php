<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h4 class="mt-4"><?php echo $titulo; ?></h4>

            <div>
                <p>
                    <a href="<?php echo base_url(); ?>/alumnos/indexAbono" class="btn btn-info">Agregar</a>
                    <a href="<?php echo base_url(); ?>/pagos/eliminados" class="btn btn-warning">Eliminados</a>
                </p>
            </div>


            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Alumno:</th>
                        <th>Monto Cancelado</th>
                        <th>Descuento</th>
                        <th>Forma de pago</th>
                        <th>Folio de boleta</th>
                        <th>Año de deuda</th>
                        <th>Fecha de pago</th>
                        <th>Fecha de ingreso</th>
                        <th>Cajero:</th>
                        <th>Comentario</th>
                        <th>Concepto:</th>

                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($datos as $dato) { ?>
                        <tr>
                            <td><?php echo $dato['id']; ?></td>
                            <td><?php echo $dato['alumno']; ?> <?php echo $dato['apellidos']; ?> <?php echo $dato['apematerno']; ?></td> 
                            <td><?php echo number_format($dato['monto'], 0, ',', '.');  ?></td>
                            <td><?php echo $dato['beneficio']; ?></td>
                            <td><?php echo $dato['forma_pago']; ?></td>
                            <td><?php echo $dato['folio_boleta']; ?></td>
                            <td><?php echo $dato['ano_deuda']; ?></td>
                            <td><?php echo $dato['fecha_pago']; ?></td>
                            <td><?php echo $dato['fecha_alta']; ?></td>
                            <td><?php echo $dato['cajero']; ?></td>
                            <td><?php echo $dato['comentario']; ?></td>
                            <td><?php echo $dato['razon_pago']; ?></td>
                            
                            
                            

                           

                            <td><button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#EliminarModal" data-bs-whatever="<?= base_url('/pagos/eliminar/' . $dato['id']) ?>"><i class="far fa-trash-alt"></i></td>
                            

                        </tr>



                    <?php } ?>

                </tbody>
            </table>
        </div>

    </main>

    <!--- Inicio Modal -->
    <div class="modal fade " id="EliminarModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Eliminar Registro de Pago?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    ¿Deseas Eliminar este registro de pago?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <a href="#" class="modal-btn-ok btn btn-primary">Aceptar</a>
                </div>
            </div>
        </div>
    </div>
    <!--- Fin Modal -->