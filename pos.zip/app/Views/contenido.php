<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1>Hola Vista Nueva</h1>
        </div>
    </main>
